function arg(...a) {
    total = a.length;
    console.log('argumnets are: ' + a);
    console.log('total number of arguments passed: ' + total)
}
arg(1, 2);