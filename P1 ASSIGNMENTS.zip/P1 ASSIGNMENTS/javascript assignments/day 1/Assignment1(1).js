let number;
let divider,flag;
for( number=5;number<=50 ;number++)
{
    for(divider=2;divider<number;divider++)
    {

    
    if(number%divider==0)
    {
        flag==1;
        break;
    }
    else{
        flag==0;
        console.log("prime number are:" + number);
        break;

    }



    }

}
    

