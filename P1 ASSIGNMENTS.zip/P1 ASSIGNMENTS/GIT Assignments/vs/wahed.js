// function array(a)
//  {
//     oddnum = function odd(a)
//      {
//         for (let i = 0; i < array.length; i++)
//         {
//             if (a[i]%2!==0)
//              {
//                 document.writeln(a[i]);                
//             } 
//         }
//     }
//     evennum = function even(a)
//      {
//         for (let i = 0; i < array.length; i++)
//          {
//             if (a[i]%2==0)
//             {
//                 document.writeln(a[i]);
//             }
//          }
//     }
//  }
//   var arr=[1,2,3,4,5,6,7,8,9];
//  array.oddnum();
//  array.evennum();

// function myfunction(){

// let array = [1,2,3,4,5,6,7,8,9,10,11,12]
// let odds = array.filter(n => n%2!=0)
// let evens=array.filter(n=>n%2==0)
// }
// console.log(odds)
// console.log(evens)

let a = [1, 2, 3, 4, 5, 6]
let a1 = []
function even(c, a) {
    var c=prompt("enter your choice,type  even  or odd");
    switch (c) {
        case 'even': for (let i = 0; i < a.length; i++) {
            if (a[i] % 2 == 0) {
                console.log(a[i])
                a1.push(a[i]);
                // a1[i]=a[i]  
            }
        }
         break;
        case 'odd': for (let i = 0; i < a.length; i++) {
            if (a[i] % 2 != 0) {
                console.log(a[i])
                a1.push(a[i]);
                // a1[i]=a[i]
            }
        }
            break;
        }
}
even('even',a);
console.log(a1);
even('odd',a)
console.log(a1);
