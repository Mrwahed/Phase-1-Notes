function odd()
 {
    for (let i = 0; i < arr.length; i++)
        {
            if (arr[i]%2!=0)
            {
                console.log(arr[i]);                
            }        
        }
} 
function even()
{
        for (let i = 0; i < arr.length; i++)
         {
            if (arr[i]%2==0)
            {
                console.log(arr[i]);
            }
         }
}
 var arr=[1,2,3,4,5,6,7,8,9];
  //enter odd=1 or even=0
 function callme(x)
 {
   if (x==1) {
    odd();
   }
   if (x==0) {
    even();
   }
 }
 callme(1);