const promise = new Promise((resolve, reject) => {

    setTimeout(() => {

      	resolve("foo");

    }, 300);

  });

  

  promise

    .then((data) => data +" A")

    .then((data) => "A " +data)

    .then((data) => "B " + data)

    .then((data) => console.log(data))