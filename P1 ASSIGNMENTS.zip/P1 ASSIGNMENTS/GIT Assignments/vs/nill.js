let longrunning = () => {
    return new Promise((res, rej) => {
    if(10 >= Math.abs((-2- -8)))
    {
    res("SUCCESS");
    }
    else
    {
    rej("FAILED");
    }
    });
    }
    let result = undefined;
    async function Start()
    {
    console.log(await result);
    }
    Start();
    console.log("Done");
    