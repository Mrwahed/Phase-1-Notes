function DrawPolygon(point1: number=0, ...points: number[]): void
{
    console.log(`Polygon drawn with ${points.length} points`);
    //iterate the points
    points.forEach(p => console.log(p));
}
DrawPolygon();
DrawPolygon(1, 2, 3, 4, 5);
DrawPolygon(1);
DrawPolygon(1, 2);