class Account
{
    //data members
    // private accid: number;
    // private name: string;
    // private balance: number;

    //define a static member
    private static bankname: string = "ICICI";
    private static x: number = 0;

    constructor(private accid: 
                number=0, 
                private name: string="", 
                private balance: number=0.00)
    {
            //increment
            ++Account.x;
            this.accid = Account.x;
    }
    //instance methods
    public Deposit(amt: number) : void
    {
            this.balance += amt;
    }
    Withdraw(amt: number) : void
    {
        this.balance -= amt;
    }
    PrintDetails(): void
    {
        console.log(`Acc id: ${this.accid}`);
        //console.log(`Name: ${this.name}`);
        //console.log(`Balance: ${this.balance}`);
    }
    static GetBankName(): string
    {
        return Account.bankname;
    }
}
console.log(`Bank name is: ${Account.GetBankName()}`);
//create an object
// let acc1 = new Account();
// let acc2 = new Account(1, "ABC", 50000.00);

// acc1.PrintDetails();
// acc2.PrintDetails();

// acc1.Deposit(10000);
// acc2.Deposit(20000);
// acc1.Withdraw(5000);
// acc2.Withdraw(2000);

// acc1.PrintDetails();
// acc2.PrintDetails();

let acc1 = new Account();
let acc2 = new Account();
let acc3 = new Account();
let acc4 = new Account();
let acc5 = new Account();
acc1.PrintDetails();
acc2.PrintDetails();
acc3.PrintDetails();
acc4.PrintDetails();
acc5.PrintDetails();



