class Circle
{
    private radius: number = 0.00;

    ComputeArea(): number
    {
        return (3.14 * this.radius * this.radius);
    }
    SetRadius(r: number): void
    {
        this.radius = r;
    }
    GetRadius(): number
    {
        return this.radius;
    }

    //properties
    //getter
    public get CircleRadius(): number
    {
        return this.radius;
    }

    //setter
    public set CircleRadius(r: number)
    {
        this.radius = r;
    }
}

let c: Circle = new Circle();
//c.SetRadius(5.66);              //setter

//use a property to set a value 
c.CircleRadius = 5.66;      //setter

//console.log(`Radius is: ${c.GetRadius()}`);     //getter
//use a property to get a value 
console.log(`Radius is: ${c.CircleRadius}`);    //getter 


let area: number = c.ComputeArea();
console.log(area);
