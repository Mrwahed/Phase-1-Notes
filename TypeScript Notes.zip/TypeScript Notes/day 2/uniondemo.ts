function ContactAFriend(details: number | string)
{

}
ContactAFriend("abc@yahoo.com");
ContactAFriend(12345);

let x: number | string = 20;
x = "20";
//x = false;