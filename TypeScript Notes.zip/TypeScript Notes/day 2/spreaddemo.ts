function Print(name1: string, name2: string) : void
{
    console.log(`Name1: ${name1}`);
    console.log(`Name2: ${name2}`);
}
Print("ABC", "XYZ");

let name1: string = "ABC";
let name2: string = "XYZ";
Print(name1, name2);

//create an array of 2 names
let names: string[] = ["ABC", "XYZ"];
let names1: string[] = [...names];

let mynames: [string, string] = ["ABC", "XYZ"];
Print(...mynames);
