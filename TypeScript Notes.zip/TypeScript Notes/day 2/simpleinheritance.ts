abstract class Shape
{
    protected shapeid: number;
    protected color: string;
    public abstract Area(): void;
}
class Square extends Shape
{
    Area(): void
    {
        console.log("Every Square has an area");
    }
}
class Rectangle extends Shape
{
    Area(): void
    {
        console.log("Every Rectangle has an area");
    }
}

let sq: Square = new Square();
let rect: Rectangle = new Rectangle();
sq.Area();
rect.Area();

let sh: Shape= new Square();
sh.Area();

sh = new Rectangle();
sh.Area();

//let someshape: Shape = new Shape();   //ERROR






//write a function which calls the Area() function of any Shape
function CalculateArea(shape: Shape)
{
    shape.Area();
}
CalculateArea(new Square());        //should call Area of Square
CalculateArea(new Rectangle());        //should call Area of Rectangle