class Box
{
    protected width: number;
    protected height: number;
    protected depth: number;

    constructor(w: number, h: number, dep: number)
    {
        console.log("Box created");
        this.width = w;
        this.height = h;
        this.depth = dep;
    }

    public PrintDetails()
    {
        console.log(`Width: ${this.width}`);
        console.log(`Height: ${this.height}`);
        console.log(`Depth: ${this.depth}`);
    }

    public Volume(): void
    {
        console.log(`Volume is: ${this.width*this.height*this.depth}`);
    }
}

class BoxWeight extends Box
{
    private weight: number;
    constructor(w: number, h: number, dep: number, wg: number)
    {
        super(w, h, dep);        //call the base class constr
        this.weight = wg;
        console.log("BoxWeight created");
        
    }
    public PrintDetails()
    {
        super.PrintDetails();
        console.log(`Weight: ${this.weight}`);
    }
}

let bw: BoxWeight = new BoxWeight(1, 2, 3, 500);
bw.Volume();
bw.PrintDetails();